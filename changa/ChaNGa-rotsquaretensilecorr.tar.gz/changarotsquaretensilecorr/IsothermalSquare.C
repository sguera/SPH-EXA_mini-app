#include "ParallelGravity.h"
#include "IsothermalSquare.h"

///
/// @brief initialize parameters special simulation of isothermal rotating square with fixed sound speed
///

void IsothermalSquare::AddParams(PRM prm)
{
  dConstSoundSpeed = 1.0;  // value for constant sound speed
  prmAddParam(prm,"dConstSoundSpeed", paramDouble, &dConstSoundSpeed, sizeof(dConstSoundSpeed), "dConstSoundSpeed",
	      "<Constant Sound Speed> = 1.");

  dDeltaX0Squared = 1.0;  //  needed for tensile stability control calc.
  prmAddParam(prm,"dDeltaX0Squared", paramDouble, &dDeltaX0Squared, sizeof(dDeltaX0Squared), "dDeltaX0Squared",
	      "<Mean Local Particle Spacing> = 1.");
}

//void IsothermalSquare::CheckParams(PRM prm, struct parameters &param)


