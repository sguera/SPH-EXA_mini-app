#ifndef ISOTHERMALSQUARE_HINCLUDED
#define ISOTHERMALSQUARE_HINCLUDED

#include "parameters.h"

/// @brief Isothermal Rotating Square parameters 
class IsothermalSquare {
 public:
  double dConstSoundSpeed;		/* Constant Sound Speed for rotating square patch*/
  double dDeltaX0Squared;                       /* Initial Mean Local Particle Spacing, for local tensile stability calc */

  void AddParams(PRM prm);
  inline void pup(PUP::er &p);
};


inline void IsothermalSquare::pup(PUP::er &p) {
  p | dConstSoundSpeed;
  p | dDeltaX0Squared;
}

#endif

    
